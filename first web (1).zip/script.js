// Fade-in on scroll
const fadeElements = document.querySelectorAll('.fade-in');

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
    }
  });
}, {
  threshold: 0.2
});

fadeElements.forEach(el => {
  observer.observe(el);
});

// Form Submit Message
document.querySelector("form").addEventListener("submit", function (e) {
  e.preventDefault();
  alert("✅ Thank you for booking with Kanhaji Tour and Travels!\n📞 We will contact you shortly.");
  this.reset();
});

// Optional Background Texture using Canvas
document.addEventListener("DOMContentLoaded", () => {
  const canvas = document.createElement('canvas');
  canvas.id = "bgTexture";
  canvas.style.position = "fixed";
  canvas.style.top = 0;
  canvas.style.left = 0;
  canvas.style.width = "100%";
  canvas.style.height = "100%";
  canvas.style.zIndex = "-1";
  canvas.style.opacity = "0.05";
  document.body.appendChild(canvas);

  const ctx = canvas.getContext("2d");

  function drawTexture() {
    const w = canvas.width = window.innerWidth;
    const h = canvas.height = window.innerHeight;

    for (let i = 0; i < 150; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      const radius = Math.random() * 1.5;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fillStyle = "#000000";
      ctx.fill();
    }
  }

  drawTexture();
  window.addEventListener("resize", drawTexture);
});