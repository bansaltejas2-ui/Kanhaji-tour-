// 1. Smooth scroll for internal anchor links (optional future use)
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault();
    document.querySelector(this.getAttribute("href")).scrollIntoView({
      behavior: "smooth"
    });
  });
});

// 2. Fade-in animation when sections enter viewport
const fadeElements = document.querySelectorAll('.fade-in');

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = 1;
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, {
  threshold: 0.2
});

fadeElements.forEach(el => {
  el.style.opacity = 0;
  el.style.transform = 'translateY(30px)';
  el.style.transition = 'opacity 1s ease, transform 1s ease';
  observer.observe(el);
});

// 3. Stylish form submission alert
document.querySelector("form").addEventListener("submit", function (e) {
  e.preventDefault();
  alert("✅ Thank you for booking with Kanhaji Tour and Travels!\n📞 We will contact you shortly.");
  this.reset();
});

// 4. OPTIONAL: Background texture effect (particles using canvas)
document.addEventListener("DOMContentLoaded", () => {
  const canvas = document.createElement('canvas');
  canvas.id = "bgTexture";
  canvas.style.position = "fixed";
  canvas.style.top = 0;
  canvas.style.left = 0;
  canvas.style.width = "100%";
  canvas.style.height = "100%";
  canvas.style.zIndex = "-1";
  canvas.style.opacity = "0.05";
  document.body.appendChild(canvas);

  const ctx = canvas.getContext("2d");

  function drawTexture() {
    const w = canvas.width = window.innerWidth;
    const h = canvas.height = window.innerHeight;

    for (let i = 0; i < 100; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      const radius = Math.random() * 1.5;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fillStyle = "#000000";
      ctx.fill();
    }
  }

  drawTexture();
  window.addEventListener("resize", drawTexture);
});